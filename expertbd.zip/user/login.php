<!DOCTYPE html>
<html lang="en">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
        <title>ExparteBD.com - Sign In</title>
    <link rel="icon" type="image/png" href="../assets/images/icon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/images/iconBig.png">
    <link rel="stylesheet" href="css/style.css">
    <!-- font awesome 6.2 -->
    <link rel="stylesheet" href="js/ajax/libs/font-awesome/6.2.0/css/all.min.css">
     <style>
            a {
                text-decoration: none;
            }
            .bg-img-plan {
            background-image: url('NtRhdh4/F2068-FAD-708-E-4-A9-E-83-C2-2-B876-BF722-F1.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            padding: 10px 20px 0;
            border-radius: 15px;
            }
            .bg-img-ads {
            background-image: url('JFhHjh1/Free-Ad-Backgrounds.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            padding: 10px 20px 0;
            border-radius: 15px;
            }
            .bg-img-deposit {
            background-image: url('jkFv6Z7/vip-bgsfsdaner.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            padding: 10px 20px 0;
            border-radius: 15px;
            }
            .bg-img-withdraw {
            background-image: url('jkFv6Z7/vip-bgsfsdaner.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            padding: 10px 20px 0;
            border-radius: 15px;
            }
        </style> 

        <!-- Edit Done  -->
    <meta name="title" Content="Exparte20.com - Sign In">
    <meta name="description" content="Pyple is a complete and ultimate PHP Script for Pay Per Click Platform. It developed with Laravel and Bootstrap 4.">
    <meta name="keywords" content="ptc,ads,earning,usa">
    <link rel="shortcut icon" href="assets/images/logoIcon/favicon.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="assets/images/logoIcon/logo.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Exparte20.com - Sign In">
    <meta itemprop="name" content="Exparte20.com - Sign In">
    <meta itemprop="description" content="">
    <meta itemprop="image" content="assets/images/seo/631ed6abcc0221662965419.jpg">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Pyple - View Ads &amp;amp; Earn Money">
    <meta property="og:description" content="Pyple is a complete and ultimate PHP Script for Pay Per Click Platform. It developed with Laravel and Bootstrap 4.">
    <meta property="og:image" content="assets/images/seo/631ed6abcc0221662965419.jpg"/>
    <meta property="og:image:type" content="image/jpeg" />
        <meta property="og:image:width" content="600" />
    <meta property="og:image:height" content="315" />
    <meta property="og:url" content="http://exparte20.com/login">
    <meta name="twitter:card" content="summary_large_image">
</head>
<body style="background-color: rgb(243, 243, 243);">
  <!-- loader -->
    <!-- <div id="loader">
        <div class="loader-n">
            <div class="l-one"></div>
            <div class="l-two"></div>
          </div>
    </div> -->
    <!-- * loader -->
  <div class="page-wrapper">
    <!-- App Header -->
    <div class="appHeader no-border transparent position-absolute">
        <div class="left">
            <a href="#" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
            <a href="register.php" class="headerButton">
                Register
            </a>
        </div>
    </div>
    <!-- * App Header -->
    <!-- App Capsule -->
    <div id="appCapsule">
        <div class="section mt-2 text-center">
            <h1>Log in</h1>
            <h4>Fill the form to log in</h4>
        </div>
        <div class="section mb-5 p-2">
            <form class="action-form mt-50 loginForm" action="loginback.php" method="post">
                <input type="hidden" name="_token" value="vv2Y2YvBVyP3ITgPwAPGn8EgfVhRBLt7Qm2yXqYl">                
                <div class="card">
                    <div class="card-body pb-1">
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label">Username</label>
                                <input type="username" name="username" class="form-control" placeholder="Your Username">
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>
                            </div>
                        </div>
                        <div class="form-group basic">
                            <div class="input-wrapper">
                                <label class="label">Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Your Password">
                                <i class="clear-input">
                                    <ion-icon name="close-circle"></ion-icon>
                                </i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-links mt-2">
                    <div>
                        <a href="register.html"></a>
                    </div>
                    <div>
                        <a href="password/reset.html">Forgotten Password?</a>
                    </div>
                </div>
                <div class="form-group d-flex justify-content-center">
                                  </div><!-- form-group end -->
                <div class="form-button-group  transparent">
                    <button type="submit" class="btn btn-primary btn-block btn-lg cmn-btn">Log in</button>
                </div>
            </form>
        </div>
    </div>
    <!-- * App Capsule -->
  </div> <!-- page-wrapper end -->
  <!-- bootstrap 5 js -->
  <script src="npm/bootstrap-5.0.2/dist/js/bootstrap.bundle.min.js" ></script>
    <!-- jQuery library -->
  <script src="assets/templates/basic/js/vendor/jquery-3.5.1.min.js"></script>
  <!-- bootstrap js -->
  <script src="assets/templates/basic/js/vendor/bootstrap.bundle.min.js"></script>
  <!-- lightcase plugin -->
  <script src="assets/templates/basic/js/vendor/lightcase.js"></script>
  <!-- custom select js -->
  <script src="assets/templates/basic/js/vendor/jquery.nice-select.min.js"></script>
  <!-- slick slider js -->
  <script src="assets/templates/basic/js/vendor/slick.min.js"></script>
  <!-- scroll animation -->
  <script src="assets/templates/basic/js/vendor/wow.min.js"></script>
  <!-- dashboard custom js -->
  <script src="assets/templates/basic/js/app.js"></script>
  </body>
<link rel="stylesheet" href="assets/global/css/iziToast.min.css">
<script src="assets/global/js/iziToast.min.js"></script>
<script type="text/javascript">
    (function($,document){
        "use strict";
                        function notify(status,message) {
            iziToast[status]({
                message: message,
                position: "topRight"
            });
        }
    })(jQuery);
</script>
    <script>
      (function ($,document) {
            "use strict";
            $('.loginForm').on('submit',function(){
              var response = grecaptcha.getResponse();
              if(response.length == 0) {
                document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:red;">Captcha field is required.</span>';
                return false;
              }
              return true;
            });
              function verifyCaptcha() {
                  document.getElementById('g-recaptcha-error').innerHTML = '';
              }
        })(jQuery,document);
    </script>
 <!-- ========= JS Files =========  -->
    <!-- Bootstrap -->
    <script src="assets/templates/basic/assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="ionicons-5.5.2/dist/ionicons/ionicons.js"></script>
    <!-- Splide -->
    <script src="assets/templates/basic/assets/js/plugins/splide/splide.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/templates/basic/assets/js/base.js"></script>
    <script>
        // Add to Home with 2 seconds delay.
        AddtoHome("2000", "once");
    </script>
<script type="text/javascript">
  (function($,document){
        "use strict";
        $(document).on('change', '#langSel', function () {
            var code = $(this).val();
            window.location.href = "http://exparte20.com/change-lang/"+code ;
        });
        $('.policy').on('click',function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.get('http://exparte20.com/cookie/accept', function(response){
                iziToast.success({message: response, position: "topRight"});
                $('.cookie-policy').addClass('d-none');
            });
        });
    })(jQuery,document);
</script>
</body>
</html>
