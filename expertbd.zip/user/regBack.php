<?php
    ob_start();
    require_once '../database.php';

    if(isset($_POST['submit'])){
        $userName = $_POST['name'];
        $email = $_POST['email'];
        $country = $_POST['country'];
        $mobileNumber = $_POST['mobile'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];
        $referName = $_POST['referName'];

        // echo $userName ."  ".$lastName."  ".$email."  ". $country."  ". $mobileNumber."  ". $username."  ". $password."  ". $confirmPassword;

        if($userName != '' && $email != '' && $country != '' && $email != '' && $mobileNumber != '' && $userName != '' && $password != '' && $confirmPassword != ''){
            $insertQuery = "INSERT INTO users (name, email, country, mobileNumber, userName, password, referTo)
            VALUES ('$userName', '$email', '$country', '$mobileNumber', '$username', '$password', '$referName')";

            if($db->query($insertQuery)){
                echo "Insert user successfully...";
                header("Location: login.php");
            }
            else{
                echo "Error Occure : ". $db->errno ;
            }

        }
        else{
            echo "All field required to fill up...";
        }
        
    }

    $conn->close();
    ob_flush();
?>