<?php
    session_start();
    if(!isset($_SESSION['user_id']) && !isset($_SESSION['user_name'])){
        header("Location: ../login.php");
    }
    require_once '../../database.php';

    $user_name =  $_SESSION['user_name'];
    $user_id = $_SESSION['user_id'];
    $depo_Amount =$_POST['deposite_amount'];
    $sender_number =$_POST['sender_number'];
    $trx_id =$_POST['transaction_id'];
    $depo_method =$_POST['deposite_method'];
    $receiver_number =$_POST['recv_num'];

    //echo "Sender Number : ". $sender_number . "</br>". "trx Number : ". $trx_id . "</br>". "Method  : ". $depo_method . "</br>" . "Amount  : " . $depo_Amount . "</br>" ;

    $query = "INSERT INTO deposite (user_id, userName, sender_number, gateway, trx_id,  depo_amount, receiver_number, depo_status)
    VALUES('$user_id', '$user_name', '$sender_number', '$depo_method', '$trx_id',  '$depo_Amount', '$receiver_number', 1)";

    if($db->query($query)){
        echo "insert Success";
        header("Location: ../depoHistory.php");
    }
    else{
        echo "insertion failed...";
        header("Location: userdepo.php");
    }
?>