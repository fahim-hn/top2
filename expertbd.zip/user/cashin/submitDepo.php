<?php
    session_start();
    if(!isset($_SESSION['user_id']) && !isset($_SESSION['user_name'])){
        header("Location: ../login.php");
    }
    $method_Code = $_POST['method_code'];
    $amount = $_POST['depo_amount'];
    //echo "Deposite amount ". $amount;
    if($method_Code == 1000)    $method = "Bkash";
    elseif($method_Code == 1001)    $method = "Nagad";
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
        <title>Exparte20 .COM - Deposit Confirm</title>
        <meta http-equiv="x-ua-compatible" content="ie=edge">

            <meta name="viewport" content="width=device-width, initial-scale=1" />

        <link rel="shortcut icon" type="image/png" href="https://exparte20.com/assets/images/logoIcon/favicon.png"/>
        <!-- bootstrap 4  -->
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/vendor/bootstrap.min.css">
      <!-- fontawesome 5  -->
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/all.min.css">
       <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/style.css">
      <!-- line-awesome webfont -->
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/line-awesome.min.css">
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/ionicons.min.css">
      <!-- image and videos view on page plugin -->
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/lightcase.css">
      
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/vendor/animate.min.css">
      <!-- custom select css -->
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/vendor/nice-select.css">
      <!-- slick slider css -->
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/vendor/slick.css">
      <!-- dashdoard main css -->
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/main.css">
      <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/custom.css">
        <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic/css/color.php?color1=3fad44&amp;color2=001d4a">

    <meta name="title" Content="Exparte20 .COM - Deposit Confirm">
    <meta name="description" content="idlc24 is a complete and ultimate PHP Script for Pay Per Click Platform. It developed with Laravel and Bootstrap 4.">
    <meta name="keywords" content="ppc,ptc,pay per click,earn money,ppv,pay per view,paid click,earn per click,ptclab">
    <!-- Apple Stuff -->
    <link rel="apple-touch-icon" href="https://exparte20.com/assets/images/logoIcon/logo.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Exparte20 .COM - Deposit Confirm">
    <!-- Google / Search Engine Tags -->
    <meta itemprop="name" content="Exparte20 .COM - Deposit Confirm">
    <meta itemprop="description" content="idlc24 is a complete and ultimate PHP Script for Pay Per Click Platform. It developed with Laravel and Bootstrap 4.">
    <meta itemprop="image" content="https://exparte20.com/assets/images/seo/64f8bd1db70921694022941.png">
    <!-- Facebook Meta Tags -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="idlc24- Pay Per Click Platform">
    <meta property="og:description" content="idlc24 is a complete and ultimate PHP Script for Pay Per Click Platform. It developed with Laravel and Bootstrap 4.">
    <meta property="og:image" content="https://exparte20.com/assets/images/seo/64f8bd1db70921694022941.png"/>
    <meta property="og:image:type" content="image/png" />
        <meta property="og:image:width" content="600" />
    <meta property="og:image:height" content="315" />
    <meta property="og:url" content="https://exparte20.com/user/deposit/manual">
    <!-- Twitter Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//css/bootstrap-fileinput.css">
    <style type="text/css">
    .withdraw-thumbnail{
        max-width: 220px;
        max-height: 220px
    }
</style>
    
</head>
<body>
  <div class="page-wrapper">
      <!-- header-section start  -->
    <div class="appHeader no-border">
        <div class="left">
            <a href="javascript:;" class="headerButton goBack">
                <i class="las la-angle-left"></i>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
        </div>
    </div>
 


<body>
    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="#" class="navbar-toggler ml-auto" type="button" data-toggle="modal" data-target="#sidebarPanel">
                <span class="menu-toggle"></span>
                
            </a>
        </div>
        <div class="pageTitle">
            <img src="https://exparte20.com/assets/images/logoIcon/logo.png" alt="logo" class="logo">
        </div>
        <div class="right">
            <a href="https://exparte20.com/user/profile-setting" class="headerButton">
                <img src="https://exparte20.com/assets/images/user/user.png" alt="image" class="imaged w32">
            </a>
        </div>
    </div>
    <!-- * App Header -->

<section class="cmn-section">
   <div class="container">
       <div class="row mb-60-80 justify-content-center">
           <div class="col-md-12">
               <div class="card">
                   <div class="card-body  ">
                        <form action="submitDepoBack.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="cB0GORN4CV5WjpObf6mdc9UqrFueKfIirsMkhb6n">                            <div class="row">
                                
                                <div class="col-md-12 text-center">
                                    <p class="text-center mt-2">You have requested  <b
                                            class="text-success"><?php echo $amount;?> BDT</b> , Please pay                                         <b class="text-success"><?php echo $amount;?> BDT</b>  for successful payment                                    </p>
                                    <h4 class="text-center mb-4">Please follow the instruction bellow</h4>

                                    <p class="my-4 text-center"><font size="5"><b>Send Money</b></font><div><b><font size="6">01971459164</font></b></div></p>

                                </div>

                                
                                    
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label><strong>Sender Number  <span class="text-danger">*</span>  </strong></label>
                                            <input type="text" class="form-control form-control-lg"
                                                    name="sender_number"  value="" placeholder="Sender Number">
                                        </div>
                                    </div>
                                
                            
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label><strong>Transaction id  <span class="text-danger">*</span>  </strong></label>
                                            <input type="text" class="form-control form-control-lg"
                                                    name="transaction_id"  value="" placeholder="Transaction id">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <input type="hidden" name="deposite_amount" value="<?php echo $amount;?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name="deposite_method" value="<?php echo $method;?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name="recv_num" value="01953966146">
                                    </div>
                                    
                                

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit"
                                                class="btn cmn-btn btn-block mt-2 text-center">Pay Now</button>
                                    </div>
                                </div>

                            </div>

                        </form>
                    </div>
               </div>
           </div>
       </div>
   </div>
 </section>

    <!-- App Sidebar -->
    <div class="modal fade panelbox panelbox-left" id="sidebarPanel" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <!-- profile box -->
                    <div class="profileBox pt-2 pb-2">
                        <div class="image-wrapper">
                             <!-- <img src="#" alt="image" class="imaged w32"> -->
                        </div>
                        <div class="in">
                            <strong></strong>
                            <div class="text-muted"></div>
                        </div>
                        <a href="#" class="btn btn-link btn-icon sidebar-close" data-dismiss="modal">
                            <ion-icon name="close-outline"></ion-icon>
                        </a>
                    </div>
                    <!-- * profile box -->
                    <!-- balance -->
                    <!-- <div class="sidebar-balance">
                        <div class="listview-title">Balance</div>
                        <div class="in">
                            <h3 class="amount"></h3>
                        </div>
                    </div> -->
                     <!-- action group -->
                    <div class="action-group">
                        <a href="https://exparte20.com/user/deposit" class="action-button">
                            <div class="in">
                                <div class="iconbox">
                                    <i class=" menu-icon las la-credit-card"></i>
                                </div>
                                Deposit
                            </div>
                        </a>
                        <a href="https://exparte20.com/user/withdraw" class="action-button">
                            <div class="in">
                                <div class="iconbox">
                                    <i class="menu-icon las la-cloud-download-alt"></i>
                                </div>
                                Withdraw
                            </div>
                        </a>
                        <a href="#" class="action-button">
                            <div class="in">
                                <div class="iconbox">
                                    <i class="menu-icon las la-hand-holding-usd"></i>
                                </div>
                                Send
                            </div>
                        </a>
                    </div>
                     <!-- * action group -->

                    <!-- menu -->
                    <div class="listview-title mt-1">Menu</div>
                    <ul class="listview flush transparent no-line image-listview">
                        <li>
                            <a href="https://exparte20.com/user/dashboard" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-home"></i>
                                </div>
                                <div class="in">
                                    Home
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/deposit" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-piggy-bank"></i>
                                </div>
                                <div class="in">
                                    Deposit
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/deposit/history" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-archive"></i>
                                </div>
                                <div class="in">
                                    Deposit History
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/withdraw" class="item">
                                <div class="icon-box bg-primary">
                                   <i class="las la-donate"></i>
                                </div>
                                <div class="in">
                                    Withdraw
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/withdraw/history" class="item">
                                <div class="icon-box bg-primary">
                                   <i class="las la-archive"></i>
                                </div>
                                <div class="in">
                                    Withdraw History
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/plans" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-lightbulb"></i>
                                </div>
                                <div class="in">
                                    Plan
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/ptc" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-tasks"></i>
                                </div>
                                <div class="in">
                                    Daily work
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/transactions" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-exchange-alt"></i>
                                </div>
                                <div class="in">
                                    Transction
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/commissions" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-users"></i>
                                </div>
                                <div class="in">
                                    Referal Commission 
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/referred-users" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-users"></i>
                                </div>
                                <div class="in">
                                    Referal User 
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/profile-setting" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-user-friends"></i>
                                </div>
                                <div class="in">
                                    Profile
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/ticket" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-ticket-alt"></i>
                                </div>
                                <div class="in">
                                    Support
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/change-password" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-key"></i>
                                </div>
                                <div class="in">
                                    change password 
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/user/twofactor" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-shield-alt"></i>
                                </div>
                                <div class="in">
                                    Two factor
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="https://exparte20.com/logout" class="item">
                                <div class="icon-box bg-primary">
                                    <i class="las la-sign-out-alt"></i>
                                </div>
                                <div class="in">
                                    Log out 
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- * App Sidebar -->

    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Jquery -->
    <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
    <!-- Bootstrap-->
    <script src="assets/js/lib/popper.min.js"></script>
    <script src="assets/js/lib/bootstrap.min.js"></script>
    
    <!-- Owl Carousel -->
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>


</body>
</html>



  </div> <!-- page-wrapper end -->
    <!-- jQuery library -->
  <script src="https://exparte20.com/assets/templates/basic//js/vendor/jquery-3.5.1.min.js"></script>
  <script src="https://exparte20.com/assets/templates/basic//js/lib/jquery-3.4.1.min.js"></script>
  <!-- bootstrap js -->
  <script src="https://exparte20.com/assets/templates/basic//js/vendor/bootstrap.bundle.min.js"></script>
  <script src="https://exparte20.com/assets/templates/basic//js/lib/popper.min.js"></script>
   <script src="https://exparte20.com/assets/templates/basic//js/lib/bootstrap.min.js"></script>
  <!-- lightcase plugin -->
  <script src="https://exparte20.com/assets/templates/basic//js/vendor/lightcase.js"></script>
  <!-- custom select js -->
  <script src="https://exparte20.com/assets/templates/basic//js/vendor/jquery.nice-select.min.js"></script>
  <!-- slick slider js -->
  <script src="https://exparte20.com/assets/templates/basic//js/vendor/slick.min.js"></script>
  <!-- scroll animation -->
  <script src="https://exparte20.com/assets/templates/basic//js/vendor/wow.min.js"></script>
  <!-- dashboard custom js -->
  <script src="https://exparte20.com/assets/templates/basic//js/app.js"></script>
  
    <!-- Owl Carousel -->
    <script src="https://exparte20.com/assets/templates/basic//js/owl.carousel.min.js"></script>
    <!-- Base Js File -->
    <script src="https://exparte20.com/assets/templates/basic//js/base.js"></script>
  </body>



<link rel="stylesheet" href="https://exparte20.com/assets/templates/basic//global/css/iziToast.min.css">
<script src="https://exparte20.com/assets/templates/basic//global/js/iziToast.min.js"></script>


<script src="https://exparte20.com/assets/templates/basic//js/bootstrap-fileinput.js"></script>


<link rel="stylesheet" href="https://exparte20.com/assets/admin/css/iziToast.min.css">
<script src="https://exparte20.com/assets/admin/js/iziToast.min.js"></script>

<script type="text/javascript">
    (function($,document){
        "use strict";
                        function notify(status,message) {
            iziToast[status]({
                message: message,
                position: "topRight"
            });
        }
    })(jQuery);
</script>



<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
(function ($) {
    "use strict";
    // apex-bar-chart js
    var options = {
      series: [{
      name: 'Clicks',
      data: [
              ]
    }, {
      name: 'Earn Amount',
      data: [
                  ]
    }],
      chart: {
      type: 'bar',
      height: 580,
      toolbar: {
        show: false
      }
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '55%',
        endingShape: 'rounded'
      },
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      show: true,
      width: 2,
      colors: ['transparent']
    },
    xaxis: {
      categories: [
          ],
    },
    fill: {
      opacity: 1
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return val
        }
      }
    }
    };
    var chart = new ApexCharts(document.querySelector("#apex-bar-chart"), options);
    chart.render();
        function createCountDown(elementId, sec) {
            var tms = sec;
            var x = setInterval(function() {
                var distance = tms*1000;
                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                document.getElementById(elementId).innerHTML =days+"d: "+ hours + "h "+ minutes + "m " + seconds + "s ";
                if (distance < 0) {
                    clearInterval(x);
                    document.getElementById(elementId).innerHTML = "COMPLETE";
                }
                tms--;
            }, 1000);
        }
      createCountDown('counter', 46921);
})(jQuery);
</script>


<script type="text/javascript">
  (function($,document){
        "use strict";
        $(document).on('change', '#langSel', function () {
            var code = $(this).val();
            window.location.href = "https://exparte20.com/change-lang/"+code ;
        });
            
    })(jQuery,document);
</script>
</body>
</html>
