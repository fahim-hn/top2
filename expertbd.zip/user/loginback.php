<?php
    ob_start();
    session_start();
    require_once '../database.php';

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    // prevent from injection
    $username = stripslashes($username);
    $password = stripslashes($password);
    $username = mysqli_real_escape_string($db,$username);
    $password = mysqli_real_escape_string($db,$password);

    if($username != '' && $password != ''){
        $query = "SELECT * FROM users WHERE userName = '$username' and password = '$password'";
        $result = $db->query($query);
        if($result->num_rows > 0){
            echo $result->num_rows;
            $row = $result->fetch_assoc();
            echo " Login Successful...";
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['user_name'] = $row['userName'];
            //echo $_SESSION['user_id'] . "  " . $_SESSION['user_name'];
            header("Location: dashboard.php");
        }
        else{
            echo "Incorrect username password..";
        }
    }
    ob_flush();
?>