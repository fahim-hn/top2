<!DOCTYPE html>
<html lang="en">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
        <title>ExpartBD.com - Home</title>
       
    <link rel="icon" type="image/png" href="assets/images/icon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/icon.png">
    <link rel="stylesheet" href="user/css/style.css">


    <!-- font awesome 6.2 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

            
       
        
     <style>
            
            a {
                text-decoration: none;
            }
            
            .bg-img-plan {
            background-image: url('https://i.ibb.co/NtRhdh4/F2068-FAD-708-E-4-A9-E-83-C2-2-B876-BF722-F1.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            padding: 10px 20px 0;
            border-radius: 15px;
            }
            
            .bg-img-ads {
            background-image: url('https://i.ibb.co/JFhHjh1/Free-Ad-Backgrounds.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            padding: 10px 20px 0;
            border-radius: 15px;
            }
            
            .bg-img-deposit {
            background-image: url('https://i.ibb.co/jkFv6Z7/vip-bgsfsdaner.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            padding: 10px 20px 0;
            border-radius: 15px;
            }
            
            .bg-img-withdraw {
            background-image: url('https://i.ibb.co/jkFv6Z7/vip-bgsfsdaner.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            padding: 10px 20px 0;
            border-radius: 15px;
            }
            
        </style> 

    <meta name="title" Content="ExpartBD.com - Home">
    <meta name="description" content="ExpertBD is a complete.">
    <meta name="keywords" content="ptc,ads,earning,usa">
    <link rel="shortcut icon" href="assets/images/icon.png" type="image/x-icon">

    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="ExpartBD.com - Home">
    
    <meta itemprop="name" content="ExpartBD.com - Home">
    <meta itemprop="description" content="">
    
    <meta property="og:type" content="website">
    <meta property="og:title" content="ExpertBD - View Ads &amp;amp; Earn Money">
    <meta property="og:description" content="ExpertBD is a complete and ultimate website for Pay Per Click Platform.">
        

</head>
<body style="background-color: rgb(243, 243, 243);">



  <!-- loader -->
    <div id="loader">
        <div class="loader-n">
            <div class="l-one"></div>
            <div class="l-two"></div>
          </div>
    </div>
    <!-- * loader -->

   

  
  <div class="page-wrapper">
      

            <!-- edit Done  -->
     <!-- App Header -->
    <div class="appHeader bg-primary text-light mb-4">
        <div class="left">
            <a href="#" class="headerButton" data-bs-toggle="modal" data-bs-target="#sidebarPanel">
                <ion-icon name="menu-outline"></ion-icon>
            </a>
        </div>
        
        <div class="pageTitle">
            <img src="assets/images/logo.png" alt="logo" class="logo">
        </div>
        
        <div class="right">
            <a href="#" class="headerButton" data-toggle="modal" data-target="#exampleModalCenter">
                <ion-icon class="icon" name="notifications-outline"></ion-icon>
            </a>
            
        </div>
    </div>
    <!-- * App Header -->

   
            <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<script type="text/javascript">
    $(window).on('load', function() {
        $('#staticBackdrop').modal('show');
        $('#staticBackdrop').modal({backdrop: 'static', keyboard: false})
    });
</script>

<!-- Modal Login-->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Login Alert :</h5>
          <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
        </div>
        <div class="modal-body">
          You must login to use everyting. Thank you..
        </div>
        <div class="modal-footer">
          
          <a href="user/login.php" class="btn btn-primary bg-primary">Login Now</a>
        </div>
      </div>
    </div>
  </div>



<!-- App Sidebar -->
<div class="modal fade panelbox panelbox-left" id="sidebarPanel" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                
                
                <!-- action group -->
                <div class="action-group">
                    <a href="user/deposit" class="action-button">
                        <div class="in">
                            <div class="iconbox">
                                <ion-icon name="arrow-up-outline"></ion-icon>
                            </div>
                            Deposit
                        </div>
                    </a>
                    
                    <a href="#" class="action-button">
                        <div class="in">
                            <div class="iconbox">
                                <ion-icon name="cloud-download-outline"></ion-icon>
                            </div>
                           Official App
                        </div>
                    </a>
                    
                    <a href="user/login.php" class="action-button">
                        <div class="in">
                            <div class="iconbox">
                                <ion-icon name="log-in-outline"></ion-icon>
                            </div>
                            Login
                        </div>
                    </a>
                    
                    <a href="user/register.php" class="action-button">
                        <div class="in">
                            <div class="iconbox">
                                <ion-icon name="person-add-outline"></ion-icon>
                            </div>
                            Register
                        </div>
                    </a>
                    
                   
                </div>
                <!-- * action group -->

                <!-- menu  Edit done -->
                <div class="listview-title mt-1">Menu</div>
                <ul class="listview flush transparent no-line image-listview">
                    <li>
                        <a href="https://expartebd.com" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="home-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Home
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="/home-plan" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="gift-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Membership Plan
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="/privacy" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="bug-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Privacy Policy
                            </div>
                        </a>
                    </li>
                </ul>
                <!-- * menu -->

                <!-- others -->
                <div class="listview-title mt-1">Others</div>
                <ul class="listview flush transparent no-line image-listview">
                    <li>
                        <a href="https://expartebd.com/about" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="school-outline"></ion-icon>
                            </div>
                            <div class="in">
                                About Us
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="whatsapplink" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="call-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Contact Us
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="telegramlink" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="paper-plane-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Join Telegram
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="user/login.php" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="log-in-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Login
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="user/register.php" class="item">
                            <div class="icon-box bg-primary">
                                <ion-icon name="person-add-outline"></ion-icon>
                            </div>
                            <div class="in">
                                Sign Up
                            </div>
                        </a>
                    </li>


                </ul>
                <!-- * others -->

               

            </div>
        </div>
    </div>
</div>
<!-- * App Sidebar -->




<!-- App Bottom Menu -->
    <div class="appBottomMenu">
        <a href="https://expartebd.com" class="item active">
            <div class="col">
                <ion-icon name="home-outline"></ion-icon>
                <strong>Home</strong>
            </div>
        </a>
        <a href="https://expartebd.com/user/ptc" class="item ">
            <div class="col">
                <ion-icon name="extension-puzzle-outline"></ion-icon>
                <strong>Task</strong>
            </div>
        </a>
        <a href="https://expartebd.com/user/plans" class="item ">
            <div style="margin-top: -15px;" class="action-button bg-primary">
                <ion-icon style="font-size: 32px;" name="basket"></ion-icon>
                
            </div>
        </a>
        <a href="#" class="item ">
            <div class="col">
                <ion-icon name="paper-plane-outline"></ion-icon>
                <strong>Contact Us</strong>
            </div>
        </a>
        <a href="user/login.php" class="item">
            <div class="col">
                <ion-icon name="log-in-outline"></ion-icon>
                <strong>Login</strong>
            </div>
        </a>
    </div>
    <!-- * App Bottom Menu -->
        


    <div class="container pt-4 pb-1 mt-5">
        
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
            
            <div style="height: 100%;" class="carousel-inner shadow rounded">

                                <div class="carousel-item active">
                    <img src="assets/images/banner/6321d9afd6de91663162799.png" class="d-block w-100" alt="...">
                </div>

                                <div class="carousel-item ">
                    <img src="assets/images/banner/6321d9a2c53e81663162786.png" class="d-block w-100" alt="...">
                </div>

                
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
            
            
        </div>
      
    </div> 

        <div class="container mt-1 pb-0">
                
                <div class="row rounded bg-primary shadow-sm">
                    
                    <div align="center" class="col-1 pt-1 mb-0">
                        <ion-icon name="volume-high-outline" style="font-size: 20px;color: #ffffff"></ion-icon>
                    </div>
                    <div class="col-11">
                        <marquee behavior="scroll" direction="left">
                            <h5 class="align-middle text-light mt-1 mb-0">
                                    This is exparteBD . It's a Earning Website.                            </h5>
                        </marquee>
                    </div>
                    
                </div>
        </div>

        
        
        

            <!-- Notice Modal Start -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Notice:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <p class="my-3">
                        <div style="text-align:center;"><b><font color="#33cc00" style="font-size:1rem;">This is </font><font size="5" color="#3300ff">exparteBD</font><font size="6" style="color:rgb(51,204,0);">.</font><span style="color:rgb(51,204,0);font-size:1rem;"> It's a Earning Website.</span></b></div>                    </p>
                  </div>
                  
                </div>
              </div>
            </div>
            <!-- Notice Modal end -->
              
        
        
            <!-- App Header -->
    <div class="appHeader bg-primary text-light mb-4">

    <!--
        <div class="left">
            <a href="#" class="headerButton" data-bs-toggle="modal" data-bs-target="#sidebarPanel">
                <ion-icon name="menu-outline"></ion-icon>
            </a>
        </div>
    -->
        <!-- Edit Done  -->
        <div class="pageTitle">
            <img src="assets/images/logoIcon/logo.png" alt="logo" class="logo">
        </div>
        
        <div class="right">
            <a href="#" class="headerButton" data-toggle="modal" data-target="#exampleModalCenter">
                <ion-icon class="icon" name="notifications-outline"></ion-icon>
                <span class="badge badge-warning">1</span>
            </a>
            
        </div>
    </div>
    <!-- * App Header -->

    <style>
       
        
        .vertical-center {
          margin: 0;
          
          top: 50%;
          -ms-transform: translateY(-50%);
          transform: translateY(-50%);
        }
        </style>

        
        <!-- * menu dashboard -->
        <div class="container pt-2">

            <div class="row">

                <div align="center" class="col-6">

                    <a href="#">
                        <div style="border-radius: 6px;" class="stat-box bg-white row-6 p-2">
                            <h6>Help Center</h6> 
                            <img src="https://i.ibb.co/tZPwBB7/help.png" width="35%" alt="help-center" border="0"> 
                        </div>
                    </a>

                    <a href="#">
                        <div style="border-radius: 6px;" class="stat-box bg-white row-6 p-2 mt-2">
                            <h6>App Download</h6> 
                            <img src="https://i.ibb.co/nPccXqw/app-download.png" width="36%" alt="help-center" border="0"> 
                        </div>
                    </a>

                </div>


                <div align="left" style="align-items: center;" class="col-6">

                    <a href="https://exparte20.com/user/referred-users">
                        <div style="height: 100%; border-radius: 6px;" class="stat-box bg-white row-6 p-2">
                            <h6>Invite Firends</h6> </br> 
                            <img align="right" src="https://i.ibb.co/ygJfSvK/reffer.png" style="bottom:5px;" width="65%" alt="help-center" border="0"> 
                        </div>
                    </a>

                </div>

            </div>

            <div class="row mt-2">

                <div align="center" class="col-6">

                    <a href="#">
                        <div style="border-radius: 6px;" class="stat-box bg-white row-6 p-2">
                            <h6>Video Tutorial</h6> 
                            <img src="https://i.ibb.co/qB7Xq2Q/video.png" width="35%" alt="help-center" border="0"> 
                        </div> 
                    </a>
                    
                </div>


                <div align="center" style="align-items: center;" class="col-6">

                    <a href="https://exparte20.com/about">
                        <div style="height: 100%; border-radius: 6px;" class="stat-box bg-white row-6 p-2">
                            <h6>About Us!</h6> 
                            <img src="https://i.ibb.co/c6J8VBh/about.png" width="35%" alt="help-center" border="0"> 
                        </div>
                    </a>

                </div>

            </div>

        </div>
        <!-- * menu dashboard -->
        
 
 
 
 
 
        <!--
    <div class="container">
       <div style="background-color: rgb(255, 255, 255);" class="container pt-2 pb-2 mt-2">

            <div class="row">
                <div align="center" class="col"><a href="https://exparte20.com/user/ptc"><ion-icon name="extension-puzzle" style="font-size: 30px;color:rgb(247, 184, 47)"> </ion-icon><br/> <h6>Task</h6></a></div>
                <div align="center" class="col"><a href="https://exparte20.com/user/plans"><ion-icon name="diamond" style="font-size: 30px;color:rgb(228, 0, 106)"> </ion-icon><br/> <h6>Membership</h6></a></div>
                <div align="center" class="col"><a href="https://exparte20.com/user/referred-users"><ion-icon name="person-add" style="font-size: 30px;color:rgb(38, 189, 0)"> </ion-icon> <br/> <h6>Invite</h6></a></div>
                <div align="center" class="col"><a href="#"><ion-icon name="videocam" style="font-size: 30px;color: red"> </ion-icon><br/> <h6>Tutorial</h6></a></div>
            </div>
            

        </div>
    </div>
        -->        
    
    
        
        
         <div class="container mt-2">
            <img class="rounded shadow" style="width: 100%; height: 100%;" src="https://i.ibb.co/7kwHvnY/302154b4e66d57ca558ade39b3773f36cce3851b-2-690x309.gif" alt="">
        </div>
        


        <section style="height: 120px;">
    
        </section>
        
        
   
    


       

    
    

    
    






  </div> <!-- page-wrapper end -->
  
  
  
  <!-- bootstrap 5 js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  
  
  
    <!-- jQuery library -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <!-- bootstrap js -->
  <!-- <script src="https://exparte20.com/assets/templates/basic//js/vendor/bootstrap.bundle.min.js"></script> -->
  <!-- lightcase plugin -->
  <script src="js/lightcase.js"></script>
  <!-- custom select js -->
  <script src="js/jquery.nice-select.min.js"></script>
  <!-- slick slider js -->
  <script src="js/slick.min.js"></script>
  <!-- scroll animation -->
  <script src="js/wow.min.js"></script>
  <!-- dashboard custom js -->
  <script src="js/app.js"></script>
  </body>



<link rel="stylesheet" href="global/css/iziToast.min.css">
<script src="global/js/iziToast.min.js"></script>

<script type="text/javascript">
    (function($,document){
        "use strict";
                        function notify(status,message) {
            iziToast[status]({
                message: message,
                position: "topRight"
            });
        }
    })(jQuery);
</script>





 <!-- ========= JS Files =========  -->
    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <!-- Ionicons -->
    <script type="module" src="js/ionicons.js"></script>
    <!-- Splide -->
    <script src="js/splide/splide.min.js"></script>
    <!-- Base Js File -->
    <script src="js/base.js"></script>

    <script>
        // Add to Home with 2 seconds delay.
        AddtoHome("2000", "once");
    </script>










<script type="text/javascript">
  (function($,document){
        "use strict";
        $(document).on('change', '#langSel', function () {
            var code = $(this).val();
            window.location.href = "https://exparte20.com/change-lang/"+code ;
        });

        $('.policy').on('click',function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.get('https://exparte20.com/cookie/accept', function(response){
                iziToast.success({message: response, position: "topRight"});
                $('.cookie-policy').addClass('d-none');
            });
        });
            
    })(jQuery,document);
</script>
</body>
</html>
