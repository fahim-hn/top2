<?php
    $server = "localhost";
    $db_user = "root";
    $db_password = "";
    $dbName = "ads_earn";

    $db = new mysqli($server,$db_user,$db_password,$dbName);

    if($db->connect_errno){
        die("Connection Failed :". $db->connect_errno);
    }
?>