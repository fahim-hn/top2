<?php
    session_start();
    require_once '../database.php';

    function jhalai_data($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if($_POST['admin_username']!='' and $_POST['admin_pass'] != ''){
            $adminUsername = $_POST['admin_username'];
            $adminPassword = $_POST['admin_pass'];
            $adminUsername = jhalai_data($adminUsername);
            $adminPassword = jhalai_data($adminPassword);

            $sql = "SELECT * FROM admin WHERE username='$adminUsername' AND password = '$adminPassword'";

            $result = $db->query($sql);
            if($result->num_rows > 0){
                $_SESSION['admin_username'] = $adminUsername;
                $db->close();
                header("Location: index.php");
                exit();
            }
            else{
                header("Location: adminLogin.php?error=loginFailed");
            }
        }
    }
?>