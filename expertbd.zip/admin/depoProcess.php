<?php
require_once '../database.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $deposit_id = $_POST["deposit_id"];

    if (isset($_POST["accept"])) {
        $newStatus = 2;
    } elseif (isset($_POST["reject"])) {
        $newStatus = 3;
    }

    $depoUpdateQuery = "UPDATE deposite SET depo_status = ? WHERE depo_id  = ?";
    $stmt = $db->prepare($depoUpdateQuery);
    $stmt->bind_param("ii",$newStatus,$deposit_id);
    if($stmt->execute()){
        $stmt->close();
        $db->close();
        header("Location: depoRequest.php");
        exit();
    }
    else{
        echo "Update Failed ... Please try again..". $stmt->error;
    }
}
?>
